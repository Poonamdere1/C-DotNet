﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assingment_2
{
    public class Engine
    {
        public int Cc { get; set; }
        public Engine(int cc)
        {
            this.Cc = cc;
        }
        public void StartEngine()
        {
            Console.WriteLine($"Engine with {Cc} has started Vroom!");
        }
    }
    class Car1
    {
        public string Color { get; set; }
        public string Make { get; set; }
        private Engine carEngine;

        public Car1(string color, string make, int engineCc)
        {
            Color = color;
            Make = make;
            // Instantiating the internal Engine object
            carEngine = new Engine(engineCc);
        }
        public void startCar()
        {
            Console.WriteLine($"Attempting to start the {Color} {Make}...");
            carEngine.StartEngine();
        }
    }

    internal class EngineClient
    {
        static void Main(string[] args)
        {
            Car1 mycar = new Car1("Red", "Sedan", 1500);
            mycar.startCar();

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assingment_2

{
    class Person
    {
        public string Name;
        public int Age;
        public Person(String name, int age)
        {
            Name = name;
            Age = age;
        }
        public void DisplayPerson()
        {
            Console.WriteLine("Name:" + Name);
            Console.WriteLine("Age:" + Age);
        }

    }
    class Employee: Person 
    {
        public int empid;
        public Employee(String name, int age, int empid) : base(name, age)
        {
            this.empid = empid;

        }
        public void DisplayEmployee()
        {
            base.DisplayPerson();
            Console.WriteLine("EmployeeID:" + empid);

        }
    }


    internal class program

    {
        public static void Main2()
        {
            Employee emp = new Employee("Poonam", 24, 100);
            emp.DisplayEmployee();
        }
    }
}

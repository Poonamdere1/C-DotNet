﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assingment_2
{
    class Vehicle
    {
        public string vehicleType;

        public Vehicle(string vehicleType)
        {
            this.vehicleType = vehicleType;
            Console.WriteLine("Vehicle Constructor Callled");

        }
        public void displayV()
        {
            Console.WriteLine("vehicle Type:" + vehicleType);
        }

    }
    class Car : Vehicle
    {
        public string brand;
        public Car(string type, string Brand) : base(type)
        {
            brand = Brand;
            Console.WriteLine("Car Constructor Called");

        }
        public void displayCar()
        {
            Console.WriteLine("Brand:" + brand);
        }
    }

    class ElectricalCar : Car
    {
        public int BatteryCapacity;

        public ElectricalCar(string type, string brand, int capacity) : base(type, brand)
        {
            this.BatteryCapacity = capacity;
            Console.WriteLine("Electrical Constructor Called");

        }
        public void Display()
        {
            base.displayCar();
            Console.WriteLine("Battery Capacity:" + BatteryCapacity);
        }

    }


    internal class progarm2
    {

        static void Main3()
        {
            ElectricalCar ec = new ElectricalCar("Electric Vehicle", "Tesla", 75);

            Console.WriteLine("\nDetails:");
            ec.Display();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assingment_2
{
    public class Company
    {
        public static string CompanyName;

        // Static Constructor
        static Company()
        {
            Console.WriteLine("--> Company: Static Constructor executed.");
            CompanyName = "TechCorp";
        }

        // Instance Constructor
        public Company()
        {
            Console.WriteLine("--> Company: Instance Constructor executed.");
        }
    }

    public class Department : Company {
        public string dept;
        static Department()
        {
            Console.WriteLine("Static Department Constructor is called");
        }
        public Department(String deptname)
        {
            Console.WriteLine("Department Instance Constructor are called");
            this.dept = deptname;

        }

    }

    internal class CompanyClient
    {

        public static void Main1(String[] args)
        {
            Console.WriteLine("--- Creating Department Object 1 ---");
            Department dept1 = new Department("Engineering");

            Console.WriteLine("\n--- Creating Department Object 2 ---");
            Department dept2 = new Department("Marketing");

        }
    }
}

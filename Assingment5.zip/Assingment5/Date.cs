﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assingmentno3
{
    internal class Date
    {
        private int DD { get; set; }
        private int MM { get; set; }
        private int YY { get; set; }

        public Date(int d, int m, int yy)
        {
            DD = d;
            MM = m;
            YY = yy;

        }
        public Date()
        {
            DD = 3;
            MM = 2;
            YY = 2003;

        }
        public static Date ReadDate()
        {
            Console.Write("Enter day: ");
            int d = int.Parse(Console.ReadLine());
            Console.Write("Enter month: ");
            int m = int.Parse(Console.ReadLine());
            Console.Write("Enter year: ");
            int y = int.Parse(Console.ReadLine());

            return new Date(d, m, y);
        }
        public void display()
        {
            Console.WriteLine($"{DD}/{MM}/{YY}");
        }
        public void Increament()
        {
            int[] dayInMonth = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

            if ((YY % 4 == 0 && YY % 100 != 0) || (YY % 400 == 0))
            {
                dayInMonth[2] = 29;
            }
            DD++;

            if (DD > dayInMonth[MM])
            {
                DD = 1;
                MM++;
            }

            if (MM > 12)
            {
                MM = 1;
                YY++;

            }
        }
        public static bool operator >(Date d1, Date d2)
        {
            if (d1.YY != d2.YY) return d1.YY > d2.YY;
            if (d1.MM != d2.MM) return d1.MM > d2.MM;
            return d1.DD > d2.DD;
        }

        public static bool operator <(Date d1, Date d2)
        {
            if (d1.YY != d2.YY) return d1.YY < d2.YY;
            if (d1.MM != d2.MM) return d1.MM < d2.MM;
            return d1.DD < d2.DD;
        }
        class DateClient { }
        public static void Main()
        {
            Console.WriteLine("--Enter Date 1----");
            Date d1 = new Date();
            Console.WriteLine("----Enter Date 2----");
            Date d2 = Date.ReadDate();

            Console.Write("\n Date 1:");
            d1.display();
            Console.Write("Date2:");
            d2.display();

            if (d1 > d2)
            {
                Console.WriteLine("Date 1 is greater than date 2");

            }
            else
            {
                Console.WriteLine("Date 1 is not greater than date 2");

            }
            Console.WriteLine("INcrement Date 1 by one dat....");

            d1.display();
            Console.Write("New Date 1:");
            d1.display();



        }
    }
}

﻿using MySqlConnector;

namespace Assingmentno5
{
    internal class BookDB
    {
        static void Main1(string[] args)
        {
            string constr = "server=localhost;database=LibraryDB;user=root;password=root";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(constr))
                {
                    conn.Open();

                    string query = "SELECT * FROM Book";

                    MySqlCommand cmd = new MySqlCommand(query, conn);

                    MySqlDataReader dr = cmd.ExecuteReader();

                    Console.WriteLine("BookId\tName\tPrice");

                    while (dr.Read())
                    {
                        Console.WriteLine($"{dr["BookId"]}\t{dr["Name"]}\t{dr["Price"]}");
                    }

                    dr.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

            Console.ReadKey();
        }
    }
}
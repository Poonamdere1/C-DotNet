﻿using System;
using System.Collections.Generic;
using System.Linq; // Added to enable LINQ methods
using System.Text;

namespace Assingmentno3
{
    class Student
    {
        public int no { get; set; }
        public string name { get; set; }
        public string language { get; set; }
        public int age { get; set; }
        public string city { get; set; }

        public Student(int no, string name, string language, int age, string city)
        {
            this.no = no;
            this.name = name;
            this.language = language;
            this.age = age;
            this.city = city;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Student> g = new List<Student>()
            {
                new Student(123, "Arun", "C#", 23, "Pune"),
                new Student(124, "Alshay", "C++", 20, "Pune"),
                new Student(125, "Rama", "C++", 22, "Nashik"),
                new Student(126, "Riya", "C#", 25, "Nagar"),
                new Student(127, "Amar", "Java", 20, "Pune"),
                new Student(128, "Vidya", "VB", 22, "Nashik"),
                new Student(129, "Prajacta", "Java", 25, "Nagar")
            };

            // 1. Query Syntax
            var puneStudentsQuery = from s in g
                                    where s.city.StartsWith("Pune")
                                    select s;

            // 1. Method Syntax
            var puneStudentsMethod = g.Where(s => s.city.StartsWith("Pune"));

            // Printing the results
            Console.WriteLine("Students in Pune:");
            foreach (var student in puneStudentsMethod)
            {
                Console.WriteLine($"ID: {student.no}, Name: {student.name}, City: {student.city}");
            }

            Console.ReadLine();
        }
    }
}
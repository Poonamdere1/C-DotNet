﻿using MySqlConnector;

namespace Assingmentno5
{
    internal class InsertBook
    {
        static void Main(string[] args)
        {
            string constr = "server=localhost;database=LibraryDB;user=root;password=root";

            using (MySqlConnection conn = new MySqlConnection(constr))
            {
                conn.Open();

                Console.Write("Enter Book Id: ");
                int id = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Book Name: ");
                string name = Console.ReadLine();

                Console.Write("Enter Price: ");
                int price = Convert.ToInt32(Console.ReadLine());

                string query = "INSERT INTO Book VALUES(@id,@name,@price)";

                MySqlCommand cmd = new MySqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@name", name)

                cmd.Parameters.AddWithValue("@price", price);

                int rows = cmd.ExecuteNonQuery();

                Console.WriteLine(rows + " Record Inserted");
            }
        }
    }
}
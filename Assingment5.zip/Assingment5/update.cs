﻿using MySqlConnector;

namespace Assingmentno5
{
    internal class UpdateBook
    {
        static void Main(string[] args)
        {
            string constr = "server=localhost;database=LibraryDB;user=root;password=root";

            using (MySqlConnection conn = new MySqlConnection(constr))
            {
                conn.Open();

                Console.Write("Enter Book Id: ");
                int id = Convert.ToInt32(Console.ReadLine());

                string query = "UPDATE Book SET Price = 300 WHERE BookId = @id";

                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);

                int rows = cmd.ExecuteNonQuery();

                Console.WriteLine(rows + " Record Updated");
            }
        }
    }
}
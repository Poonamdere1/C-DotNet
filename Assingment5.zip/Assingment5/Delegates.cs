﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assingmentno3
{
   
    public delegate void StringDelegate(string s);
    public delegate int MathDelegate(int a, int b);

    internal class Delegates
    {
        public static void Upper(string s) => Console.WriteLine(s.ToUpper());
        public static void Lower(string s) => Console.WriteLine(s.ToLower());
        public static void Print(string s) => Console.WriteLine(s);

        public static int Add(int a, int b) => a + b;
        public static int Subtract(int a, int b) => a - b;
        public static int Multiply(int a, int b) => a * b;

        public static bool IsPositive(int no) => no >= 0;

        public static void Main()
        {
            // --- Assignment 1 ---
            StringDelegate singleCastVoid = new StringDelegate(Upper);
            Console.Write("Single Cast: ");
            singleCastVoid("hello delegates");

            StringDelegate multiCastVoid = Upper;
            multiCastVoid += Lower;
            multiCastVoid += Print;
            Console.WriteLine("\nMulticast:");
            multiCastVoid("Testing Multicast");

            Action<string> actionDelegate = Print;
            Console.Write("\nAction Delegate: ");
            actionDelegate("Hello from Action");

            // --- Assignment 2 ---
            StringDelegate anonVoid = delegate (string s) { Console.WriteLine(s.ToUpper()); };
            Console.Write("\nAnonymous Method: ");
            anonVoid("anon method call");

            Action<string> lambdaVoid = s => Console.WriteLine(s.ToLower());
            Console.Write("\nLambda Function: ");
            lambdaVoid("LAMBDA METHOD CALL");

            // --- Assignment 3 ---
            MathDelegate singleCastInt = new MathDelegate(Add);
            Console.WriteLine($"\nSingle Cast (Add): {singleCastInt(10, 5)}");

            MathDelegate multiCastInt = Add;
            multiCastInt += Subtract;
            multiCastInt += Multiply;
            Console.WriteLine($"Multicast (Returns last method - Multiply): {multiCastInt(10, 5)}");

            Func<int, int, int> funcDelegate = Add;
            Console.WriteLine($"Func Delegate (Add): {funcDelegate(20, 30)}");

            // --- Assignment 4 ---
            Console.WriteLine("\n=== ASSIGNMENT 4 ===");
            MathDelegate anonInt = delegate (int a, int b) { return a + b; };
            Console.WriteLine($"Anonymous Method (Add): {anonInt(8, 2)}");

            Func<int, int, int> lambdaInt = (a, b) => a * b;
            Console.WriteLine($"Lambda Function (Multiply): {lambdaInt(6, 5)}");

            // --- Assignment 5 ---
            Console.WriteLine("\n=== ASSIGNMENT 5 ===");
            Predicate<int> isPositivePredicate = IsPositive;

            int testNum1 = 15;
            int testNum2 = -5;

            Console.WriteLine($"Is {testNum1} positive? {isPositivePredicate(testNum1)}");
            Console.WriteLine($"Is {testNum2} positive? {isPositivePredicate(testNum2)}");

            Console.ReadLine();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AssignmentNo4
{
    class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Course { get; set; }
        public int Marks { get; set; }
        public string City { get; set; }

        public Student(int id, string name, string course, int marks, string city)
        {
            Id = id;
            Name = name;
            Course = course;
            Marks = marks;
            City = city;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Student> students = new List<Student>()
            {
                new Student(1, "Amit", "C#", 85, "Pune"),
                new Student(2, "Neha", "Java", 72, "Mumbai"),
                new Student(3, "Ravi", "C#", 90, "Pune"),
                new Student(4, "Sneha", "Python", 65, "Delhi"),
                new Student(5, "Rahul", "Java", 88, "Mumbai"),
                new Student(6, "Priya", "C#", 55, "Pune")
            };

            Console.WriteLine("================ QUERY SYNTAX ================");

            Console.WriteLine("\n--- 1. Name and City ---");
            var q1 = from s in students
                     select new { s.Name, s.City };

            foreach (var item in q1)
            {
                Console.WriteLine($"Name: {item.Name}, City: {item.City}");
            }

            Console.WriteLine("\n--- 2. Name, Course, Marks (Marks > 70) ---");
            var q2 = from s in students
                     where s.Marks > 70
                     select new { s.Name, s.Course, s.Marks };

            foreach (var item in q2)
            {
                Console.WriteLine($"Name: {item.Name}, Course: {item.Course}, Marks: {item.Marks}");
            }

            Console.WriteLine("\n--- 3. Property Renaming (StudentName and StudentMarks) ---");
            var q3 = from s in students
                     select new { StudentName = s.Name, StudentMarks = s.Marks };

            foreach (var item in q3)
            {
                Console.WriteLine($"StudentName: {item.StudentName}, StudentMarks: {item.StudentMarks}");
            }


            Console.WriteLine("\n================ METHOD SYNTAX ================");

            Console.WriteLine("\n--- 4.1. Name and City (Method Syntax) ---");
            var m1 = students.Select(s => new { s.Name, s.City });

            foreach (var item in m1)
            {
                Console.WriteLine($"Name: {item.Name}, City: {item.City}");
            }

            Console.WriteLine("\n--- 4.2. Name, Course, Marks > 70 (Method Syntax) ---");
            var m2 = students.Where(s => s.Marks > 70)
                             .Select(s => new { s.Name, s.Course, s.Marks });

            foreach (var item in m2)
            {
                Console.WriteLine($"Name: {item.Name}, Course: {item.Course}, Marks: {item.Marks}");
            }

            Console.WriteLine("\n--- 4.3. Property Renaming (Method Syntax) ---");
            var m3 = students.Select(s => new { StudentName = s.Name, StudentMarks = s.Marks });

            foreach (var item in m3)
            {
                Console.WriteLine($"StudentName: {item.StudentName}, StudentMarks: {item.StudentMarks}");
            }

            Console.ReadLine();
        }
    }
}
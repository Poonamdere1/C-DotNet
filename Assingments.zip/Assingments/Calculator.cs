﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assingments
{
    internal class Calculator
    {
    }
}

﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Text;

namespace Assingments

{
    class Date
    {
        private int dd, mm, yy;
        public int Dd
        {
            get { return dd; }
            set { dd = value; }
        }

        public int Mm
        {
            get { return mm; }
            set { mm = value; }
        }

        public int Yy
        {
            get { return yy; }
            set { yy = value; }
        }
        public Date()
        {
            dd = 03; mm = 02;yy = 2003;
        }
        public Date(int dd, int mm, int yy)//parameterised constructor
        {
            this.dd = dd;
            this.mm = mm;
            this.yy = yy;
        }
        //Constructor with dd and yy
        public Date(int dd, int yy)
        {
            this.dd = dd;
            this.mm = 1;
            this.yy = yy;
        }

        public void showDate()
        {
            Console.WriteLine($"{dd}/{mm}/{yy}");
        }
    }


    internal class progarm

    {
        public static void Main2()
        {
            Date d1 = new Date();
            Date d2 = new Date(5, 6, 2026);
            Date d3 = new Date() { Dd = 10, Mm = 12, Yy = 2025 };
            Date d4 = new Date() { Dd = 15, Yy = 2024 };
            d1.showDate();
            d2.showDate();
            d3.showDate();
            d4.showDate();



        }

    }
}

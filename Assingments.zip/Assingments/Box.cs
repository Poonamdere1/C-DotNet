﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assingments

{
    public class Box
    {
        public double Height { get; set; }
        public double Width { get; set; }
        public double Depth { get; set; }

        //default Constructor
        public Box()
        {
            Height = Width = Depth = 1;
        }

        public Box(double h, double w, double d)
        {
            Height = h;
            Width = w;
            Depth = d;
        }

        //Copy Constructor
        public Box(Box b)
        {
            Height = b.Height;
            Width = b.Width;
            Depth = b.Depth;


        }
        public double volume()
        {
            return Height * Width * Depth;
        }

    }


    internal class program2
    {
        public static void Main()
        {
            Box b1 = new Box();
            Box b2 = new Box(3, 2, 4);
            Box b3 = new Box(b2);
            Console.WriteLine("Volume of Box1=" + b1.volume());
            Console.WriteLine("Volume of Box2=" + b2.volume());
            Console.WriteLine("Volume of Box3=" + b3.volume());
        }
    }
}

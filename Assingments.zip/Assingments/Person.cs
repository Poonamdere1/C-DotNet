﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assingments
{
    class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }

        public Person(string firstName, string lastName, int age)
        {
            FirstName = firstName;
            LastName = lastName;
            Age = age;
        }

        public void Display()
        {
            Console.WriteLine("First Name: " + FirstName);
            Console.WriteLine("Last Name: " + LastName);
            Console.WriteLine("Age: " + Age);
        }
    }

    static class PersonExtensions
    {
        public static string GetFullName(this Person p)
        {
            return p.FirstName + " " + p.LastName;
        }

        public static bool IsAdult(this Person p)
        {
            return p.Age >= 18;
        }
    }

    internal class PersonExtends
    {
        static void Main()
        {
            Person p1 = new Person("Poonam", "Dere", 22);

            p1.Display();

            Console.WriteLine("Full Name: " + p1.GetFullName());

            Console.WriteLine("Is Adult: " + p1.IsAdult());
        }

    }
}

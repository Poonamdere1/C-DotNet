﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Collection
{
    class student
    {
        public int rollno { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public int Age { get; set; }
        public double Marks { get; set; }

        public student(int rollno, string name, string email, int age, double marks)
        {
            this.rollno = rollno;
            this.Name = name;
            this.Email = email;
            this.Age = age;
            this.Marks = marks;
        }


    }

    class StudentName : IComparer<student>
    {
        public int Compare(student x, student y)
        {
            return x.Name.CompareTo(y.Name);
        }

    }

    class StudentAge : IComparer<student>
    {
        public int Compare(student x, student y)
        {
            return x.Age.CompareTo(y.Age);
        }
    }
    class StudentMark : IComparer<student>
    {
        public int Compare(student x, student y)
        {
            return x.Marks.CompareTo(y.Marks);
        }

    }
    //main 
    class DemoStudent
    {
        static void Display(List<student> student)
        {
            foreach (var s in student)
            {
                Console.WriteLine($"{s.rollno} {s.Name} {s.Age} {s.Marks}");

            }
            Console.WriteLine();
        }
        static void Main()
        {
            List<student> student = new List<student>();

            {
                new student(1, "Amit", "amit@gmail.com", 21, 78);
                new student(2, "Rohit", "rohit@gmail.com", 20, 85);
                new student(3, "Pooja", "pooja@gmail.com", 22, 90);
                new student(4, "Neha", "neha@gmail.com", 19, 75);
                new student(5, "Kiran", "kiran@gmail.com", 23, 88);
        };
            Console.WriteLine("Sorted by name");
            student.Sort(new StudentName());
            Display(student);


            Console.WriteLine("Sorted By Age:");
            student.Sort(new StudentAge());
            Display(student);

            Console.WriteLine("Sorted By Marks:");
            student.Sort(new StudentMark());
            Display(student);
        }


    }
}
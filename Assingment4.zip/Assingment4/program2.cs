﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Collection
{
    internal class program2
    {
        static void Main()
        {
            List<string> list = new List<string>();
            list.Add("Orange");
            list.Add("Cherry");
            list.Add("banana");
            list.Add("strowberry");
            list.Add("mango");
            list.Add("fig");
            Console.WriteLine("Count=" + list.Count());//count the no of elements
            //count the elements having length>3
            Console.WriteLine("Length>3=" + list.Count(x => x.Length > 3));
            Console.WriteLine("Length Between 4 and 7 = " +
          list.Count(x => x.Length >= 4 && x.Length <= 7));
            //asending order
            Console.WriteLine("\nDescending Order:");
            foreach (string s in list.OrderByDescending(x => x))
            {
                Console.WriteLine(s);
            }
            //Elements having length >5
            Console.WriteLine("\nLength > 5:");
            foreach (string s in list.Where(x => x.Length > 5))
            {
                Console.WriteLine(s);
            }
            //Elements starting with m
            Console.WriteLine("\n Starts with m:");
            foreach(string s in list.Where(x => x.StartsWith("m")))
            {
                Console.WriteLine(s);
            }
            Console.WriteLine("\n Starts with rry");
            foreach(string s in list.Where(x => x.EndsWith("rry")))
            {
                Console.WriteLine(s);
            }



        }
    }
}

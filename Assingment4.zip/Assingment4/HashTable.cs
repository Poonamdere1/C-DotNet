﻿using System;
using System.Collections;
using System.Text;

namespace Collection
{
    class Progarm2
    {
        static void Main()
        {
            Hashtable ht=new Hashtable();
            ht.Add("Siddhant", "123456789");
            ht.Add("Poonam", "8329550592");
            ht.Add("Gatha", "8329550593");
            ht.Add("Ved", "8529550592");
            ht.Add("Purnima", "8329550692");
            Console.WriteLine("---PhoneBokk Dictionary---");

        }
    }

}

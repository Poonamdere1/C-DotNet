﻿using System;
using System.Collections;

class Program
{
    static void Main2()
    {
        ArrayList myAL = new ArrayList();


        myAL.Add(42);
        myAL.Add("Hello World");
        myAL.Add(true);
        myAL.Add(DateTime.Now);
        myAL.Add(3.14);

        Console.WriteLine("--- Initial ArrayList ---");
        DisplayArrayList(myAL);


        myAL.Remove("Hello World");
        Console.WriteLine("\n--- After Removing 'Hello World' ---");
        DisplayArrayList(myAL);

        // c. Remove element at a particular position/index (removes index 1)
        if (myAL.Count > 1)
        {
            myAL.RemoveAt(1); // Removes whatever is currently at index 1
            Console.WriteLine("\n--- After Removing Element at Index 1 ---");
            DisplayArrayList(myAL);
        }
    }

    // Helper method to display the ArrayList
    static void DisplayArrayList(ArrayList list)
    {
        foreach (var item in list)
        {
            Console.WriteLine($"Type: {item.GetType().Name,-10} | Value: {item}");
        }
    }
}

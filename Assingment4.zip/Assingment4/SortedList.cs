﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Collection
{
    internal class progarm3
    {
        public static void Main()
        {

            SortedList<string, string> sl = new SortedList<string, string>();
            sl.Add("Amit", "9876543256");
            sl.Add("Rhohit", "9876543265");
            sl.Add("priya", "9876543216");
            sl.Add("Neha", "9876543214");
            Console.WriteLine("Sorted List");

            foreach (KeyValuePair<string, string> item in sl)
            {
                Console.WriteLine(item.Key + ":" + item.Value);
            }
            Console.Write("\nEnter name to search:");
            string name = Console.ReadLine();

            if (sl.ContainsKey(name))
                Console.WriteLine("Phone Number: " + sl[name]);
            else
                Console.WriteLine("Name Not Found");

            Console.Write("\nEnter Phone Number to Search: ");
            string phone = Console.ReadLine();

            bool found = false;

            foreach (KeyValuePair<string, string> item in sl)
            {
                if (item.Value == phone) // No more .ToString() needed!
                {
                    Console.WriteLine("Name: " + item.Key);
                    found = true;
                    break;
                }
            }

            if (!found)
                Console.WriteLine("Number Not Found");

            // Remove Name
            Console.Write("\nEnter Name to Remove: ");
            string removeName = Console.ReadLine();

            sl.Remove(removeName);

            Console.WriteLine("\nRecords After Removal:");

            foreach (KeyValuePair<string, string> item in sl)
            {
                Console.WriteLine(item.Key + " : " + item.Value);
            }

            // Display Keys
            Console.WriteLine("\nKey List:");
            foreach (string key in sl.Keys) // Strongly typed string
            {
                Console.WriteLine(key);
            }

            // Display Values
            Console.WriteLine("\nValue List:");
            foreach (string value in sl.Values) // Strongly typed string
            {
                Console.WriteLine(value);
            }





        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program2
{
    static void Main()
    {
        List<string> list = new List<string>();

        list.Add("orange");
        list.Add("cherry");
        list.Add("banana");
        list.Add("strowberry");
        list.Add("mango");
        list.Add("fig");

        // 1. Count number of elements
        Console.WriteLine("Count = " + list.Count());

        // 2. Count elements having length > 3
        Console.WriteLine("Length > 3 = " +
            list.Count(x => x.Length > 3));

        // 3. Count elements having length between 4 and 7
        Console.WriteLine("Length Between 4 and 7 = " +
            list.Count(x => x.Length >= 4 && x.Length <= 7));

        // 4. Ascending Order
        Console.WriteLine("\nAscending Order:");
        foreach (string s in list.OrderBy(x => x))
        {
            Console.WriteLine(s);
        }

        // 5. Descending Order
        Console.WriteLine("\nDescending Order:");
        foreach (string s in list.OrderByDescending(x => x))
        {
            Console.WriteLine(s);
        }

        // 6. Elements having length > 5
        Console.WriteLine("\nLength > 5:");
        foreach (string s in list.Where(x => x.Length > 5))
        {
            Console.WriteLine(s);
        }

        // 7. Elements starting with 'm'
        Console.WriteLine("\nStarts With m:");
        foreach (string s in list.Where(x => x.StartsWith("m")))
        {
            Console.WriteLine(s);
        }

        // 8. Elements ending with 'rry'
        Console.WriteLine("\nEnds With rry:");
        foreach (string s in list.Where(x => x.EndsWith("rry")))
        {
            Console.WriteLine(s);
        }
    }
}
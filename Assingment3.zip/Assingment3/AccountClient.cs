﻿using System;

namespace Polymorphisum
{
    abstract class Account
    {
        protected int accno;
        protected string name;
        protected double balance;

        public Account(int accno, string name, double balance)
        {
            this.accno = accno;
            this.name = name;
            this.balance = balance;
        }

        public abstract void Withdraw(double amount);

        public void DisplayDetails()
        {
            Console.WriteLine($"Acc No: {accno} | Name: {name} | Current Balance: ₹{balance}");
        }
    }

    class SavingAccount : Account
    {
        private const double MIN_BALANCE = 2000.0;

        public SavingAccount(int accno, string name, double balance) : base(accno, name, balance)
        {
        }

        public override void Withdraw(double amount)
        {
            Console.WriteLine("\n--- Processing Saving Account Withdrawal ---");
            base.DisplayDetails();
            Console.WriteLine($"| Requested Withdrawal : ₹{amount}");

            // Logic Fix: Check if the remaining balance stays above or equal to MIN_BALANCE
            if (this.balance - amount >= MIN_BALANCE)
            {
                this.balance -= amount;
                Console.WriteLine("Status: Success! Amount withdrawn successfully.");
                Console.WriteLine($"Updated Balance: ₹{this.balance}");
            }
            else
            {
                Console.WriteLine($"Status: Failed! Transaction denied. Balance cannot fall below the minimum required balance of ₹{MIN_BALANCE}.");
            }
        }
    }

    class RecurringAccount : Account
    {
        private double installment;

        public RecurringAccount(int accno, string name, double balance, double installment) : base(accno, name, balance)
        {
            this.installment = installment;
        }

        public override void Withdraw(double amount)
        {
            Console.WriteLine("\n--- Processing Recurring Account Withdrawal ---");
            base.DisplayDetails();
            Console.WriteLine($"| Installment Amount: ₹{installment}");
            Console.WriteLine("Status: Failed! Withdrawals are strictly NOT allowed from a Recurring Account.");
        }
    }

    internal class AccountClient
    {
        public static void Main(string[] args)
        {
            // Create an array of 5 Account objects
            Account[] accounts = new Account[5];

            Console.WriteLine("=== ENTER DETAILS FOR 5 ACCOUNTS ===");
            for (int i = 0; i < accounts.Length; i++)
            {
                Console.WriteLine($"\nEnter details for Account {i + 1}:");

                Console.Write("Type of account (Savings / Recurring): ");
                string type = Console.ReadLine().Trim();

                Console.Write("Account number: ");
                int accNo = Convert.ToInt32(Console.ReadLine());

                Console.Write("Name: ");
                string name = Console.ReadLine();

                Console.Write("Balance: ");
                double balance = Convert.ToDouble(Console.ReadLine());

               
                if (type.Equals("Savings", StringComparison.OrdinalIgnoreCase))
                {
                    accounts[i] = new SavingAccount(accNo, name, balance);
                }
                else if (type.Equals("Recurring", StringComparison.OrdinalIgnoreCase))
                {
                    Console.Write("Installment (only for Recurring Account): ");
                    double installment = Convert.ToDouble(Console.ReadLine());
                    accounts[i] = new RecurringAccount(accNo, name, balance, installment);
                }
                else
                {
                    Console.WriteLine("Invalid type entered! Defaulting to Savings Account.");
                    accounts[i] = new SavingAccount(accNo, name, balance);
                }
            }

            // Ask the user to enter the amount to withdraw
            Console.WriteLine("\n==========================================");
            Console.Write("Enter the amount to withdraw from all accounts: ₹");
            double withdrawAmount = Convert.ToDouble(Console.ReadLine());

            // Polymorphism in action
            Console.WriteLine("\n=== PROCESSING ALL WITHDRAWALS (Polymorphism in Action) ===");
            foreach (Account acc in accounts)
            {
                acc.Withdraw(withdrawAmount);
            }

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}
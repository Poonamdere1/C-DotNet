﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AssingmentNo1
{
    internal class ArrayExceptionHandling
    {

        public static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter the size of the array");
                int size = int.Parse(Console.ReadLine());
                int[] numbers = new int[size];
                Console.Write($"Enter {size} elements");
                for (int i = 0; i < size; i++)
                {
                    Console.Write($"Elements[{size}] elements");
                    numbers[i] = int.Parse(Console.ReadLine());
                }
                Console.WriteLine("ENter the index number to display");
                int index = int.Parse(Console.ReadLine());
                Console.WriteLine($"Element at index {index} is: {numbers[index]}");

            }
            catch (FormatException)
            {
                Console.WriteLine("Error:invalid input please enter numbers only");

            }
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error:the index you entered is out of array bound ");
            }
            catch (OverflowException)
            {
                Console.WriteLine("Error: The number entered is too large or too small.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An unexpected error occurred: {ex.Message}");
            }

        }
    }
}

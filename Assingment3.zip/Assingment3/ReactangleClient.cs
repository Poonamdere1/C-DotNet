﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Interface
{

    interface IDrawable
    {
        float PI { get; }
        void DrawShape();
        void CalculateArea();
        void CalculatePerimeter();
    }
    class Circle : IDrawable
    {
        public float PI => 3.14159f;
        private double radius;

        public Circle(double radius)
        {
            this.radius = radius;
        }

        public void DrawShape()
        {
            Console.WriteLine($"\nDrawing a Circle with radius: {radius}");
        }

        public void CalculateArea()
        {
            double area = PI * radius * radius;
            Console.WriteLine($"Circle Area: {area:F2}");
        }

        public void CalculatePerimeter()
        {
            double perimeter = 2 * PI * radius;
            Console.WriteLine($"Circle Perimeter (Circumference): {perimeter:F2}");
        }


    }

    class Rectangle : IDrawable
    {
        public float PI => 3.14159f; // Not used for rectangle calculation but required by interface
        private double length;
        private double width;

        public Rectangle(double length, double width)
        {
            this.length = length;
            this.width = width;
        }

        public void DrawShape()
        {
            Console.WriteLine($"\nDrawing a Rectangle with length: {length} and width: {width}");
        }

        public void CalculateArea()
        {
            double area = length * width;
            Console.WriteLine($"Rectangle Area: {area:F2}");
        }

        public void CalculatePerimeter()
        {
            double perimeter = 2 * (length + width);
            Console.WriteLine($"Rectangle Perimeter: {perimeter:F2}");
        }
    }


    internal class ReactangleClient
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("===SHAPE INTERFACE VERIFICATION");
            IDrawable[] shapes = new IDrawable[]
            {
                new Circle(5.0),
                new Rectangle(4.0, 6.0)
            };

            foreach (var shape in shapes)
            {
                shape.DrawShape();
                shape.CalculateArea();
                shape.CalculatePerimeter();
            }
            Console.ReadKey();

        }
    }
}

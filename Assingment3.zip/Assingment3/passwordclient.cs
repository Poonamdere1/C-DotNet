﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AssingmentNo1
{
    internal class passwordclient
    {
    }
}
